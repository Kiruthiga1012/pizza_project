package com.justeat.pizzaorder.dao;

import java.util.List;



import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;


public class LoginDao {

	
	  @Autowired 
	  private SessionFactory sessionFactory;
	  
	  public int validateUser(Login login) { 
		  String uname=login.getUserName();
		  String pwd=login.getPassWord(); 
		  System.out.println(uname);
		  System.out.println(pwd); 
		  Session session=sessionFactory.openSession();
	  
		 // String hql="from Login where userName="+uname+" and passWord="+pwd; 
		  String hql="select userName,passWord from Login where userName=:username and passWord=:password";
		  
		  Query query=session.createQuery(hql);
		  
		  query.setParameter("username", uname);
		  query.setParameter("password",pwd);
	  
		  List<Login> list=query.getResultList();
	  
	  if(list.isEmpty()) {
		  return 0; 
	  } 
	  else { 
		  return 1;
	  }
	  
	  }
	  
	  public int toPlaceOrder(Customer customer,PizzaOrder pizza) {
		  Session session=sessionFactory.openSession();
		  Transaction transaction=session.beginTransaction();
		  
		  pizza.setCustomerDetails(customer);
		  session.save(pizza);
		  
		  int orderId=pizza.getOrderId();
		  
		  transaction.commit();
		  session.close();
		  
		  return orderId;
	  }
	 
}
