package com.justeat.pizzaorder.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;
import com.justeat.pizzaorder.dao.LoginDao;

public class LoginService {
	
	
	  @Autowired 
	  private LoginDao loginDao;
	  
	  public int validateUser(Login login) { 
		  int row=loginDao.validateUser(login);
		  return row;
	  }
	  
	  public int toPlaceOrder(Customer customer,int topping,PizzaOrder pizza) {
		  int totalPrice=350+topping;
		  pizza.setTotalPrice(totalPrice);
		  int orderId=loginDao.toPlaceOrder(customer,pizza);
		  return orderId;
	  }
	 
}
