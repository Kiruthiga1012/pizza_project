package com.justeat.pizzaorder.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.justeat.pizzaorder.bean.Customer;
import com.justeat.pizzaorder.bean.Login;
import com.justeat.pizzaorder.bean.PizzaOrder;
import com.justeat.pizzaorder.service.LoginService;

@Controller
public class LoginController {
	
	
	  @Autowired 
	  private LoginService loginService;
	  
	  @Autowired
	  private PizzaOrder pizza;
	 

	@RequestMapping("login")
	public String login(Model m) {
		System.out.println("hello");
		m.addAttribute("login",new Login());
		return "login";
	}
	
	
	  @RequestMapping(value="/toHome", method=RequestMethod.POST) 
	  public String validateUser(@Valid @ModelAttribute("login") Login login,BindingResult result) { 
		 System.out.println(login);
		  if(result.hasErrors())  
			  return "login"; 
		  
		  else {
	   
			  int row=loginService.validateUser(login);
	  
			  if(row==1) 
				  return "home"; 
			  else 
				  return "login"; 
	  }
	  
	  }
	  
	  @RequestMapping("placeorder")
	  public String placeOrder(Model m) {
		  System.out.println("placeorder");
		  m.addAttribute("PlaceOrder", new Customer());
		  return "placeorder";
	  }
	  

	 @RequestMapping(value="/toplaceorder", method=RequestMethod.POST)
	 public String toPlaceOrder(@ModelAttribute("PlaceOrder")Customer customer,@RequestParam("topping")int topping,Model m) {
		 System.out.println(topping);
		 System.out.println(customer);
		 int orderId=loginService.toPlaceOrder(customer,topping,pizza);
		 m.addAttribute("orderId", orderId);
		 return "order";
		 
	 }
}

